import { Link } from "react-router";
import { Linkedin, Twitter, Github, Mail } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t border-border bg-background">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <h4 className="text-foreground">Alex Rivera</h4>
            <p className="text-sm text-muted-foreground">
              AI Product Manager building intelligent products that solve real problems.
            </p>
          </div>

          <div className="space-y-4">
            <h4 className="text-foreground">Navigation</h4>
            <nav className="flex flex-col space-y-2 text-sm">
              <Link to="/projects" className="text-muted-foreground hover:text-foreground transition-colors duration-200">
                Work
              </Link>
              <Link to="/about" className="text-muted-foreground hover:text-foreground transition-colors duration-200">
                About
              </Link>
              <Link to="/blog" className="text-muted-foreground hover:text-foreground transition-colors duration-200">
                Blog
              </Link>
              <Link to="/contact" className="text-muted-foreground hover:text-foreground transition-colors duration-200">
                Contact
              </Link>
            </nav>
          </div>

          <div className="space-y-4">
            <h4 className="text-foreground">Connect</h4>
            <div className="flex space-x-4">
              <a
                href="https://linkedin.com/in/alexrivera"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-card border border-border rounded-lg flex items-center justify-center hover:border-primary/50 transition-colors duration-200"
              >
                <Linkedin className="w-5 h-5 text-muted-foreground" />
              </a>
              <a
                href="https://twitter.com/alexrivera"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-card border border-border rounded-lg flex items-center justify-center hover:border-primary/50 transition-colors duration-200"
              >
                <Twitter className="w-5 h-5 text-muted-foreground" />
              </a>
              <a
                href="https://github.com/alexrivera"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-card border border-border rounded-lg flex items-center justify-center hover:border-primary/50 transition-colors duration-200"
              >
                <Github className="w-5 h-5 text-muted-foreground" />
              </a>
              <a
                href="mailto:alex.rivera@example.com"
                className="w-10 h-10 bg-card border border-border rounded-lg flex items-center justify-center hover:border-primary/50 transition-colors duration-200"
              >
                <Mail className="w-5 h-5 text-muted-foreground" />
              </a>
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="text-foreground">Location</h4>
            <p className="text-sm text-muted-foreground">
              San Francisco, CA<br />
              Available for remote work
            </p>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-border flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <p className="text-sm text-muted-foreground">
            © 2026 Alex Rivera. All rights reserved.
          </p>
          <div className="flex space-x-6 text-sm text-muted-foreground">
            <a href="#" className="hover:text-foreground transition-colors duration-200">
              Privacy Policy
            </a>
            <a href="#" className="hover:text-foreground transition-colors duration-200">
              Terms of Service
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
