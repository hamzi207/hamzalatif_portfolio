import { motion } from "motion/react";
import { Briefcase, GraduationCap, Award } from "lucide-react";

export function About() {
  return (
    <div className="pt-32 pb-20 px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="space-y-16"
        >
          {/* Header */}
          <div className="space-y-6">
            <h1 className="text-foreground">About Me</h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              Product leader specializing in AI/ML products, with 8+ years building platforms 
              that serve millions of users.
            </p>
          </div>

          {/* Bio */}
          <div className="space-y-6 text-lg text-muted-foreground leading-relaxed">
            <p>
              I'm Alex Rivera, an AI Product Manager focused on building intelligent products that 
              solve complex problems with elegant simplicity.
            </p>
            <p>
              My career spans from early-stage startups to scaling enterprise platforms. I've led 
              product teams at the intersection of machine learning, user experience, and business 
              strategy—always with a focus on shipping products that users love and businesses value.
            </p>
            <p>
              I believe the best products emerge from deep customer empathy, rigorous experimentation, 
              and the courage to make bold bets. My approach combines strategic vision with tactical 
              execution, ensuring teams move fast without breaking things.
            </p>
          </div>

          {/* Experience */}
          <div className="space-y-8">
            <div className="flex items-center space-x-3">
              <Briefcase className="w-6 h-6 text-primary" />
              <h3 className="text-foreground">Experience</h3>
            </div>
            <div className="space-y-8 border-l-2 border-border pl-8 ml-3">
              <div className="space-y-2">
                <div className="flex items-baseline justify-between">
                  <h4 className="text-foreground">Senior Product Manager, AI</h4>
                  <span className="text-sm text-muted-foreground">2021 - Present</span>
                </div>
                <p className="text-muted-foreground">TechCorp</p>
                <p className="text-muted-foreground">
                  Leading AI product strategy for enterprise decision-intelligence platform. 
                  Shipped ML-powered features serving 10K+ organizations.
                </p>
              </div>

              <div className="space-y-2">
                <div className="flex items-baseline justify-between">
                  <h4 className="text-foreground">Product Manager</h4>
                  <span className="text-sm text-muted-foreground">2019 - 2021</span>
                </div>
                <p className="text-muted-foreground">DataFlow AI</p>
                <p className="text-muted-foreground">
                  Built and scaled predictive analytics platform from 0 to 1. Managed full product 
                  lifecycle from ideation to market fit.
                </p>
              </div>

              <div className="space-y-2">
                <div className="flex items-baseline justify-between">
                  <h4 className="text-foreground">Associate Product Manager</h4>
                  <span className="text-sm text-muted-foreground">2017 - 2019</span>
                </div>
                <p className="text-muted-foreground">CloudScale</p>
                <p className="text-muted-foreground">
                  Owned developer tools and infrastructure products. Led cross-functional initiatives 
                  to improve platform reliability and developer experience.
                </p>
              </div>
            </div>
          </div>

          {/* Education */}
          <div className="space-y-8">
            <div className="flex items-center space-x-3">
              <GraduationCap className="w-6 h-6 text-primary" />
              <h3 className="text-foreground">Education</h3>
            </div>
            <div className="space-y-4 pl-9">
              <div className="space-y-2">
                <h4 className="text-foreground">MBA, Technology Management</h4>
                <p className="text-muted-foreground">Stanford Graduate School of Business</p>
              </div>
              <div className="space-y-2">
                <h4 className="text-foreground">BS, Computer Science</h4>
                <p className="text-muted-foreground">MIT</p>
              </div>
            </div>
          </div>

          {/* Skills & Expertise */}
          <div className="space-y-8">
            <div className="flex items-center space-x-3">
              <Award className="w-6 h-6 text-primary" />
              <h3 className="text-foreground">Expertise</h3>
            </div>
            <div className="grid md:grid-cols-2 gap-8 pl-9">
              <div className="space-y-4">
                <h4 className="text-foreground">Product Skills</h4>
                <ul className="space-y-2 text-muted-foreground">
                  <li>• AI/ML Product Strategy</li>
                  <li>• 0-to-1 Product Development</li>
                  <li>• Enterprise SaaS</li>
                  <li>• Data-Driven Decision Making</li>
                  <li>• User Research & Testing</li>
                </ul>
              </div>
              <div className="space-y-4">
                <h4 className="text-foreground">Technical Skills</h4>
                <ul className="space-y-2 text-muted-foreground">
                  <li>• Machine Learning Concepts</li>
                  <li>• SQL & Data Analysis</li>
                  <li>• API Design & Integration</li>
                  <li>• System Architecture</li>
                  <li>• A/B Testing & Experimentation</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Personal */}
          <div className="pt-8 border-t border-border space-y-6">
            <h3 className="text-foreground">Beyond Work</h3>
            <p className="text-lg text-muted-foreground leading-relaxed">
              When I'm not thinking about product strategy, you'll find me trail running in the 
              mountains, reading about cognitive science and human decision-making, or mentoring 
              aspiring product managers through various programs.
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
