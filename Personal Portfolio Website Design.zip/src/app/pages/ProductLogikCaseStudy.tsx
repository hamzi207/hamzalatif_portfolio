import { motion } from "motion/react";
import { Link } from "react-router";
import { 
  ArrowLeft, 
  TrendingUp, 
  Users, 
  Clock, 
  CheckCircle2,
  Brain,
  AlertTriangle,
  BarChart3,
  Target,
  Shield,
  Zap,
  Scale
} from "lucide-react";

export function ProductLogikCaseStudy() {
  return (
    <div className="pt-32 pb-20 px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="space-y-16"
        >
          {/* Back Link */}
          <Link
            to="/projects"
            className="inline-flex items-center text-muted-foreground hover:text-foreground transition-colors duration-200"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Projects
          </Link>

          {/* Header */}
          <div className="space-y-6">
            <h1 className="text-foreground">ProductLogik</h1>
            <p className="text-2xl text-muted-foreground leading-relaxed">
              Structured, explainable AI for smarter product decisions.
            </p>
            <div className="flex flex-wrap gap-2 pt-4">
              <span className="px-3 py-1 bg-card text-sm text-muted-foreground rounded-full border border-border">
                AI
              </span>
              <span className="px-3 py-1 bg-card text-sm text-muted-foreground rounded-full border border-border">
                SaaS
              </span>
              <span className="px-3 py-1 bg-card text-sm text-muted-foreground rounded-full border border-border">
                Decision Engine
              </span>
              <span className="px-3 py-1 bg-card text-sm text-muted-foreground rounded-full border border-border">
                NLP
              </span>
            </div>
          </div>

          {/* Hero Image */}
          <div className="aspect-video bg-card rounded-lg border border-border overflow-hidden">
            <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/20 to-primary/5">
              <div className="text-center space-y-4 p-8">
                <div className="w-20 h-20 bg-primary/20 rounded-2xl flex items-center justify-center mx-auto">
                  <Brain className="w-10 h-10 text-primary" />
                </div>
                <p className="text-muted-foreground">ProductLogik Platform</p>
              </div>
            </div>
          </div>

          {/* Metrics */}
          <div className="grid md:grid-cols-3 gap-8 py-8 border-y border-border">
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <TrendingUp className="w-5 h-5 text-primary" />
                <span className="text-3xl font-bold text-foreground">73%</span>
              </div>
              <p className="text-muted-foreground">Decision accuracy</p>
            </div>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Users className="w-5 h-5 text-primary" />
                <span className="text-3xl font-bold text-foreground">5K+</span>
              </div>
              <p className="text-muted-foreground">Ideas evaluated</p>
            </div>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Clock className="w-5 h-5 text-primary" />
                <span className="text-3xl font-bold text-foreground">12mo</span>
              </div>
              <p className="text-muted-foreground">Development cycle</p>
            </div>
          </div>

          {/* Problem */}
          <div className="space-y-6">
            <h2 className="text-foreground">The Problem</h2>
            <div className="space-y-4 text-lg text-muted-foreground leading-relaxed">
              <p>
                Product roadmaps are built on a foundation of gut feeling and stakeholder politics. 
                Even experienced teams struggle with three fundamental challenges:
              </p>
              <div className="space-y-4 pl-6 border-l-2 border-primary/30">
                <div className="space-y-2">
                  <h4 className="text-foreground flex items-center space-x-2">
                    <AlertTriangle className="w-5 h-5 text-primary" />
                    <span>Intuition-based decisions</span>
                  </h4>
                  <p>
                    Without structured evaluation frameworks, teams rely on the loudest voice in the room 
                    or the HiPPO (Highest Paid Person's Opinion), leading to misaligned priorities.
                  </p>
                </div>
                <div className="space-y-2">
                  <h4 className="text-foreground flex items-center space-x-2">
                    <Users className="w-5 h-5 text-primary" />
                    <span>Stakeholder bias</span>
                  </h4>
                  <p>
                    Different departments push competing agendas—sales wants features, engineering wants 
                    technical debt reduction, design wants UX improvements. No objective scoring system exists.
                  </p>
                </div>
                <div className="space-y-2">
                  <h4 className="text-foreground flex items-center space-x-2">
                    <Brain className="w-5 h-5 text-primary" />
                    <span>Lack of structured models</span>
                  </h4>
                  <p>
                    Existing frameworks (RICE, ICE, Value vs. Effort) are oversimplified and don't capture 
                    strategic alignment, risk, or long-term value creation.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Solution */}
          <div className="space-y-6">
            <h2 className="text-foreground">The Solution</h2>
            <div className="space-y-4 text-lg text-muted-foreground leading-relaxed">
              <p>
                ProductLogik combines deterministic scoring with AI-assisted reasoning to create a 
                transparent, explainable decision intelligence system. Unlike black-box AI tools, 
                ProductLogik shows its work at every step.
              </p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-6 mt-8">
              <div className="p-6 bg-card border border-border rounded-lg space-y-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Scale className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-foreground">Layer 1: Deterministic Scoring</h3>
                <p className="text-muted-foreground">
                  Weighted scoring framework evaluates ideas across 4 dimensions: Business Value, 
                  User Impact, Implementation Effort, and Strategic Alignment. Each dimension uses 
                  quantifiable sub-metrics with custom weightings.
                </p>
              </div>
              <div className="p-6 bg-card border border-border rounded-lg space-y-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Brain className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-foreground">Layer 2: AI Reasoning</h3>
                <p className="text-muted-foreground">
                  NLP engine analyzes idea descriptions to identify hidden risks, strategic conflicts, 
                  and opportunity costs. Provides natural language explanations for score adjustments 
                  and recommends refinements.
                </p>
              </div>
            </div>
          </div>

          {/* Architecture */}
          <div className="space-y-6">
            <h2 className="text-foreground">System Architecture</h2>
            <div className="bg-card border border-border rounded-lg p-8">
              <div className="space-y-6">
                {/* Layer 1 */}
                <div className="flex items-start space-x-4 p-4 bg-background rounded-lg border border-border">
                  <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-sm font-bold text-primary">1</span>
                  </div>
                  <div className="space-y-2">
                    <h4 className="text-foreground">Input Structuring (NLP)</h4>
                    <p className="text-sm text-muted-foreground">
                      Natural language processing extracts key entities, identifies business goals, 
                      and maps idea components to evaluation framework.
                    </p>
                  </div>
                </div>

                {/* Arrow */}
                <div className="flex justify-center">
                  <div className="w-px h-6 bg-border"></div>
                </div>

                {/* Layer 2 */}
                <div className="flex items-start space-x-4 p-4 bg-background rounded-lg border border-border">
                  <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-sm font-bold text-primary">2</span>
                  </div>
                  <div className="space-y-2">
                    <h4 className="text-foreground">Weighted Scoring Engine</h4>
                    <p className="text-sm text-muted-foreground">
                      Deterministic calculation using custom weightings across Value (35%), Effort (25%), 
                      Risk (20%), and Alignment (20%). Transparent, auditable math.
                    </p>
                  </div>
                </div>

                {/* Arrow */}
                <div className="flex justify-center">
                  <div className="w-px h-6 bg-border"></div>
                </div>

                {/* Layer 3 */}
                <div className="flex items-start space-x-4 p-4 bg-background rounded-lg border border-border">
                  <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-sm font-bold text-primary">3</span>
                  </div>
                  <div className="space-y-2">
                    <h4 className="text-foreground">Risk & Value Modeling</h4>
                    <p className="text-sm text-muted-foreground">
                      AI layer analyzes historical data, identifies patterns, and adjusts scores based on 
                      execution risk, market timing, and strategic dependencies.
                    </p>
                  </div>
                </div>

                {/* Arrow */}
                <div className="flex justify-center">
                  <div className="w-px h-6 bg-border"></div>
                </div>

                {/* Layer 4 */}
                <div className="flex items-start space-x-4 p-4 bg-background rounded-lg border border-border">
                  <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-sm font-bold text-primary">4</span>
                  </div>
                  <div className="space-y-2">
                    <h4 className="text-foreground">Explainable Output System</h4>
                    <p className="text-sm text-muted-foreground">
                      Priority ranking with breakdown of every score component, plain-language reasoning, 
                      and actionable refinement suggestions.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Dashboard Concept */}
          <div className="space-y-6">
            <h2 className="text-foreground">Product Interface</h2>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Clean, enterprise-grade SaaS interface designed for product teams who need clarity, 
              not complexity.
            </p>

            <div className="bg-card border border-border rounded-lg p-8 space-y-8">
              {/* Idea Input Panel */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-foreground">Idea Input Panel</h4>
                  <div className="px-2 py-1 bg-primary/10 rounded text-xs text-primary">
                    New Evaluation
                  </div>
                </div>
                <div className="p-4 bg-background rounded-lg border border-border">
                  <div className="space-y-3">
                    <div className="h-10 bg-card rounded border border-border flex items-center px-3">
                      <span className="text-sm text-muted-foreground">Enter product idea or feature description...</span>
                    </div>
                    <div className="h-24 bg-card rounded border border-border p-3">
                      <span className="text-sm text-muted-foreground">Details and context...</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Scoring Breakdown */}
              <div className="space-y-4">
                <h4 className="text-foreground">Scoring Breakdown</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-background rounded-lg border border-border space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Business Value</span>
                      <Target className="w-4 h-4 text-primary" />
                    </div>
                    <div className="text-2xl font-bold text-foreground">8.2</div>
                    <div className="w-full h-2 bg-card rounded-full overflow-hidden">
                      <div className="h-full w-[82%] bg-primary rounded-full"></div>
                    </div>
                  </div>
                  <div className="p-4 bg-background rounded-lg border border-border space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Implementation Effort</span>
                      <Zap className="w-4 h-4 text-primary" />
                    </div>
                    <div className="text-2xl font-bold text-foreground">6.5</div>
                    <div className="w-full h-2 bg-card rounded-full overflow-hidden">
                      <div className="h-full w-[65%] bg-primary rounded-full"></div>
                    </div>
                  </div>
                  <div className="p-4 bg-background rounded-lg border border-border space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Risk Assessment</span>
                      <AlertTriangle className="w-4 h-4 text-primary" />
                    </div>
                    <div className="text-2xl font-bold text-foreground">4.8</div>
                    <div className="w-full h-2 bg-card rounded-full overflow-hidden">
                      <div className="h-full w-[48%] bg-primary rounded-full"></div>
                    </div>
                  </div>
                  <div className="p-4 bg-background rounded-lg border border-border space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Strategic Alignment</span>
                      <BarChart3 className="w-4 h-4 text-primary" />
                    </div>
                    <div className="text-2xl font-bold text-foreground">9.1</div>
                    <div className="w-full h-2 bg-card rounded-full overflow-hidden">
                      <div className="h-full w-[91%] bg-primary rounded-full"></div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Priority Ranking */}
              <div className="space-y-4">
                <h4 className="text-foreground">Priority Ranking</h4>
                <div className="space-y-2">
                  {[
                    { rank: 1, name: "Advanced analytics dashboard", score: 8.7, badge: "High Priority" },
                    { rank: 2, name: "Mobile app optimization", score: 7.9, badge: "Medium" },
                    { rank: 3, name: "API rate limiting improvements", score: 6.4, badge: "Medium" },
                  ].map((item) => (
                    <div key={item.rank} className="p-4 bg-background rounded-lg border border-border flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="w-8 h-8 bg-primary/10 rounded flex items-center justify-center">
                          <span className="text-sm font-bold text-primary">{item.rank}</span>
                        </div>
                        <span className="text-sm text-foreground">{item.name}</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <span className="text-xs px-2 py-1 bg-primary/10 text-primary rounded">
                          {item.badge}
                        </span>
                        <span className="text-sm font-bold text-foreground">{item.score}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* AI Explanation Panel */}
              <div className="space-y-4">
                <h4 className="text-foreground">AI Explanation</h4>
                <div className="p-4 bg-background rounded-lg border border-border space-y-3">
                  <div className="flex items-start space-x-3">
                    <Brain className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
                    <div className="space-y-2">
                      <p className="text-sm text-muted-foreground">
                        <strong className="text-foreground">Recommendation:</strong> Prioritize this feature. 
                        Strong strategic alignment with Q2 OKRs and high user impact potential.
                      </p>
                      <p className="text-sm text-muted-foreground">
                        <strong className="text-foreground">Risk Factor:</strong> Moderate implementation 
                        complexity detected. Consider phased rollout to mitigate execution risk.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Strategic Impact */}
          <div className="space-y-6">
            <h2 className="text-foreground">Strategic Impact</h2>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="p-6 bg-card border border-border rounded-lg space-y-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Shield className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-foreground">Reduced Bias</h3>
                <p className="text-muted-foreground">
                  Structured framework eliminates HiPPO syndrome and political decision-making. 
                  Transparent scoring creates accountability and alignment across stakeholders.
                </p>
              </div>
              <div className="p-6 bg-card border border-border rounded-lg space-y-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Zap className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-foreground">Faster Validation</h3>
                <p className="text-muted-foreground">
                  Automated evaluation reduces decision cycles from weeks to hours. Teams spend 
                  less time debating and more time building the right things.
                </p>
              </div>
              <div className="p-6 bg-card border border-border rounded-lg space-y-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                  <CheckCircle2 className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-foreground">Transparent Prioritization</h3>
                <p className="text-muted-foreground">
                  Every decision is explainable. Product teams can articulate why features were 
                  prioritized or deprioritized with data-backed reasoning.
                </p>
              </div>
            </div>
          </div>

          {/* Results */}
          <div className="space-y-6">
            <h2 className="text-foreground">Results & Validation</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="p-6 bg-card border border-border rounded-lg space-y-3">
                <h4 className="text-foreground">Early Adoption</h4>
                <ul className="space-y-2 text-muted-foreground">
                  <li>• Beta tested with 8 product teams</li>
                  <li>• 5,000+ ideas evaluated in 6 months</li>
                  <li>• 73% accuracy vs. post-launch performance</li>
                  <li>• 4.6/5 product satisfaction score</li>
                </ul>
              </div>
              <div className="p-6 bg-card border border-border rounded-lg space-y-3">
                <h4 className="text-foreground">Efficiency Gains</h4>
                <ul className="space-y-2 text-muted-foreground">
                  <li>• 65% reduction in planning meetings</li>
                  <li>• 2 hours avg. time per evaluation</li>
                  <li>• 40% increase in roadmap confidence</li>
                  <li>• 28% faster feature delivery</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Learnings */}
          <div className="space-y-6">
            <h2 className="text-foreground">Key Learnings</h2>
            <div className="space-y-4 text-lg text-muted-foreground leading-relaxed">
              <p>
                <strong className="text-foreground">Explainability is non-negotiable.</strong> Product 
                teams won't trust a black-box AI. Every score, every recommendation, every risk flag 
                needs a clear explanation. The deterministic + AI hybrid approach proved essential.
              </p>
              <p>
                <strong className="text-foreground">Customization drives adoption.</strong> No two 
                companies prioritize the same way. The ability to customize weightings and evaluation 
                criteria was the difference between "interesting tool" and "mission-critical platform."
              </p>
              <p>
                <strong className="text-foreground">Change management is the real challenge.</strong> 
                The technology works, but shifting teams from intuition-based to data-driven 
                decision-making requires training, champions, and executive buy-in.
              </p>
            </div>
          </div>

          {/* CTA */}
          <div className="pt-8 border-t border-border">
            <Link
              to="/contact"
              className="inline-flex items-center text-primary hover:text-primary/80 transition-colors duration-200"
            >
              Want to discuss building decision intelligence systems? Let's talk →
            </Link>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
