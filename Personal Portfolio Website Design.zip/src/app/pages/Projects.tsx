import { motion } from "motion/react";
import { Link } from "react-router";
import { ArrowRight, Target, BarChart3, Sparkles, Users, Brain } from "lucide-react";

const projects = [
  {
    id: "ai-compass",
    title: "AI Compass",
    description: "Intelligent decision-making platform that helps product teams prioritize features using AI-powered insights.",
    tags: ["Product Strategy", "ML Integration", "Enterprise SaaS"],
    icon: Target,
    featured: true,
    link: "/projects/ai-compass",
  },
  {
    id: "productlogik",
    title: "ProductLogik",
    subtitle: "AI-Powered Product Strategy & Decision Intelligence Platform",
    description: "An explainable AI system that evaluates product ideas using structured scoring, risk modeling, and strategic alignment logic.",
    tags: ["AI", "SaaS", "Decision Engine", "NLP"],
    icon: Brain,
    featured: true,
    link: "/projects/productlogik",
  },
  {
    id: "predictive-analytics",
    title: "Predictive Analytics Suite",
    description: "End-to-end analytics platform that predicts customer churn and lifetime value with 92% accuracy.",
    tags: ["Data Science", "B2B", "Scale"],
    icon: BarChart3,
    featured: false,
    link: null,
  },
  {
    id: "smart-recommendations",
    title: "Smart Recommendations Engine",
    description: "Personalization system that increased user engagement by 45% through ML-powered content recommendations.",
    tags: ["Personalization", "ML", "Growth"],
    icon: Sparkles,
    featured: false,
    link: null,
  },
  {
    id: "team-intelligence",
    title: "Team Intelligence Platform",
    description: "Collaboration tool with AI-powered insights that helps distributed teams work more effectively.",
    tags: ["Collaboration", "AI", "Remote Work"],
    icon: Users,
    featured: false,
    link: null,
  },
];

export function Projects() {
  return (
    <div className="pt-32 pb-20 px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="space-y-16"
        >
          {/* Header */}
          <div className="space-y-6 max-w-3xl">
            <h1 className="text-foreground">Selected Work</h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              A collection of products I've built and shipped, from early concepts to 
              scaled platforms serving thousands of users.
            </p>
          </div>

          {/* Featured Project */}
          <div className="space-y-6">
            <span className="text-sm text-primary uppercase tracking-wider">Featured AI Systems</span>
            {projects
              .filter((p) => p.featured)
              .map((project) => (
                <Link
                  key={project.id}
                  to={project.link || "#"}
                  className="group block"
                >
                  <div className="grid md:grid-cols-2 gap-12 items-center p-8 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors duration-200">
                    <div className="space-y-6">
                      <div className="w-14 h-14 bg-primary/10 rounded-lg flex items-center justify-center">
                        <project.icon className="w-7 h-7 text-primary" />
                      </div>
                      <h2 className="text-foreground group-hover:text-primary transition-colors duration-200">
                        {project.title}
                      </h2>
                      <p className="text-lg text-muted-foreground leading-relaxed">
                        {project.description}
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {project.tags.map((tag) => (
                          <span
                            key={tag}
                            className="px-3 py-1 bg-background text-sm text-muted-foreground rounded-full border border-border"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                      <div className="inline-flex items-center text-primary">
                        View Case Study
                        <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform duration-200" />
                      </div>
                    </div>
                    <div className="aspect-square bg-background rounded-lg overflow-hidden">
                      <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/20 to-primary/5">
                        <project.icon className="w-32 h-32 text-primary/40" />
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
          </div>

          {/* Other Projects */}
          <div className="space-y-8">
            <span className="text-sm text-muted-foreground uppercase tracking-wider">
              Other Projects
            </span>
            <div className="grid md:grid-cols-2 gap-6">
              {projects
                .filter((p) => !p.featured)
                .map((project) => (
                  <motion.div
                    key={project.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4 }}
                    className="group p-8 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors duration-200"
                  >
                    <div className="space-y-6">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                        <project.icon className="w-6 h-6 text-primary" />
                      </div>
                      <h3 className="text-foreground group-hover:text-primary transition-colors duration-200">
                        {project.title}
                      </h3>
                      <p className="text-muted-foreground leading-relaxed">
                        {project.description}
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {project.tags.map((tag) => (
                          <span
                            key={tag}
                            className="px-3 py-1 bg-background text-sm text-muted-foreground rounded-full border border-border"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                ))}
            </div>
          </div>

          {/* CTA */}
          <div className="pt-16 text-center">
            <p className="text-lg text-muted-foreground mb-6">
              Interested in learning more about my process and approach?
            </p>
            <Link
              to="/contact"
              className="inline-flex items-center px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors duration-200"
            >
              Get in Touch
              <ArrowRight className="ml-2 w-4 h-4" />
            </Link>
          </div>
        </motion.div>
      </div>
    </div>
  );
}