import { motion } from "motion/react";
import { Link } from "react-router";
import { ArrowLeft, TrendingUp, Users, Clock, CheckCircle2 } from "lucide-react";

export function AICompassCaseStudy() {
  return (
    <div className="pt-32 pb-20 px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="space-y-16"
        >
          {/* Back Link */}
          <Link
            to="/projects"
            className="inline-flex items-center text-muted-foreground hover:text-foreground transition-colors duration-200"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Projects
          </Link>

          {/* Header */}
          <div className="space-y-6">
            <h1 className="text-foreground">AI Compass</h1>
            <p className="text-2xl text-muted-foreground leading-relaxed">
              An intelligent decision-making platform that helps product teams prioritize 
              features using AI-powered insights, reducing decision time by 60%.
            </p>
            <div className="flex flex-wrap gap-2 pt-4">
              <span className="px-3 py-1 bg-card text-sm text-muted-foreground rounded-full border border-border">
                Product Strategy
              </span>
              <span className="px-3 py-1 bg-card text-sm text-muted-foreground rounded-full border border-border">
                ML Integration
              </span>
              <span className="px-3 py-1 bg-card text-sm text-muted-foreground rounded-full border border-border">
                Enterprise SaaS
              </span>
            </div>
          </div>

          {/* Hero Image */}
          <div className="aspect-video bg-card rounded-lg border border-border overflow-hidden">
            <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/20 to-primary/5">
              <div className="text-center space-y-4 p-8">
                <div className="w-20 h-20 bg-primary/20 rounded-2xl flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-10 h-10 text-primary" />
                </div>
                <p className="text-muted-foreground">AI Compass Platform</p>
              </div>
            </div>
          </div>

          {/* Metrics */}
          <div className="grid md:grid-cols-3 gap-8 py-8 border-y border-border">
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <TrendingUp className="w-5 h-5 text-primary" />
                <span className="text-3xl font-bold text-foreground">60%</span>
              </div>
              <p className="text-muted-foreground">Faster decisions</p>
            </div>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Users className="w-5 h-5 text-primary" />
                <span className="text-3xl font-bold text-foreground">10K+</span>
              </div>
              <p className="text-muted-foreground">Active users</p>
            </div>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Clock className="w-5 h-5 text-primary" />
                <span className="text-3xl font-bold text-foreground">18mo</span>
              </div>
              <p className="text-muted-foreground">Time to market</p>
            </div>
          </div>

          {/* Challenge */}
          <div className="space-y-6">
            <h2 className="text-foreground">The Challenge</h2>
            <div className="space-y-4 text-lg text-muted-foreground leading-relaxed">
              <p>
                Product teams at enterprise companies were drowning in feature requests, 
                stakeholder opinions, and conflicting priorities. Decision-making cycles took 
                weeks, involved endless meetings, and often resulted in analysis paralysis.
              </p>
              <p>
                Existing prioritization frameworks (RICE, MoSCoW, etc.) were manual, subjective, 
                and didn't account for market dynamics or competitive intelligence. Teams needed 
                a system that could synthesize multiple data sources and provide actionable 
                recommendations—fast.
              </p>
            </div>
          </div>

          {/* Solution */}
          <div className="space-y-6">
            <h2 className="text-foreground">The Solution</h2>
            <div className="space-y-4 text-lg text-muted-foreground leading-relaxed">
              <p>
                We built AI Compass, a decision intelligence platform that combines machine learning 
                with product management best practices. The system ingests data from multiple 
                sources—user feedback, usage analytics, market research, and business metrics—to 
                generate prioritization recommendations.
              </p>
            </div>
            
            <div className="space-y-4 mt-8">
              <h3 className="text-foreground">Key Features</h3>
              <div className="space-y-3">
                {[
                  "AI-powered impact scoring that considers user value, business goals, and technical effort",
                  "Real-time competitive intelligence integration",
                  "Automated stakeholder alignment tools",
                  "Scenario modeling for roadmap planning",
                  "Natural language explanations for every recommendation",
                ].map((feature, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <CheckCircle2 className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
                    <span className="text-muted-foreground">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Process */}
          <div className="space-y-6">
            <h2 className="text-foreground">My Role & Process</h2>
            <div className="space-y-6 text-lg text-muted-foreground leading-relaxed">
              <p>
                As the lead Product Manager, I owned the end-to-end product strategy and execution:
              </p>
              
              <div className="space-y-8 border-l-2 border-border pl-8 ml-3">
                <div className="space-y-3">
                  <h4 className="text-foreground">Discovery (3 months)</h4>
                  <p>
                    Conducted 50+ customer interviews with product leaders at Fortune 500 companies. 
                    Mapped the decision-making process, identified pain points, and validated the 
                    core hypothesis that teams needed AI assistance, not just another tool.
                  </p>
                </div>

                <div className="space-y-3">
                  <h4 className="text-foreground">Design & Prototyping (2 months)</h4>
                  <p>
                    Worked closely with design to create an interface that made complex ML 
                    recommendations feel simple and trustworthy. Built a functional prototype and 
                    tested with 15 beta customers.
                  </p>
                </div>

                <div className="space-y-3">
                  <h4 className="text-foreground">Development & Launch (8 months)</h4>
                  <p>
                    Led cross-functional team of engineers, data scientists, and designers. Shipped 
                    MVP in 4 months, then iterated based on usage data and customer feedback.
                  </p>
                </div>

                <div className="space-y-3">
                  <h4 className="text-foreground">Scale & Optimization (5 months)</h4>
                  <p>
                    Focused on enterprise readiness: security, compliance, integrations, and 
                    performance. Built feedback loops to continuously improve ML model accuracy.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Results */}
          <div className="space-y-6">
            <h2 className="text-foreground">Results & Impact</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="p-6 bg-card border border-border rounded-lg space-y-3">
                <h4 className="text-foreground">Business Impact</h4>
                <ul className="space-y-2 text-muted-foreground">
                  <li>• $12M ARR in first year</li>
                  <li>• 89% customer retention rate</li>
                  <li>• Expanded to 150+ enterprise customers</li>
                  <li>• Featured in Gartner Magic Quadrant</li>
                </ul>
              </div>
              <div className="p-6 bg-card border border-border rounded-lg space-y-3">
                <h4 className="text-foreground">User Impact</h4>
                <ul className="space-y-2 text-muted-foreground">
                  <li>• 60% reduction in decision time</li>
                  <li>• 4.8/5 product satisfaction score</li>
                  <li>• 70% weekly active usage rate</li>
                  <li>• 10K+ decisions made on platform</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Learnings */}
          <div className="space-y-6">
            <h2 className="text-foreground">Key Learnings</h2>
            <div className="space-y-4 text-lg text-muted-foreground leading-relaxed">
              <p>
                <strong className="text-foreground">Trust is earned, not assumed.</strong> The biggest 
                challenge wasn't building the AI—it was designing an experience that helped users 
                understand and trust the recommendations. We invested heavily in explainability, 
                showing our work at every step.
              </p>
              <p>
                <strong className="text-foreground">Start simple, then scale.</strong> Our first version 
                had 1/3 of the features we initially planned. Turns out, teams just wanted fast, 
                reliable impact scoring. We added complexity only after validating core value.
              </p>
              <p>
                <strong className="text-foreground">Change management is product work.</strong> Building 
                the product was half the battle. Helping teams adopt new decision-making processes 
                required dedicated onboarding, training, and customer success engagement.
              </p>
            </div>
          </div>

          {/* CTA */}
          <div className="pt-8 border-t border-border">
            <Link
              to="/contact"
              className="inline-flex items-center text-primary hover:text-primary/80 transition-colors duration-200"
            >
              Interested in discussing this project in detail? Let's talk →
            </Link>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
