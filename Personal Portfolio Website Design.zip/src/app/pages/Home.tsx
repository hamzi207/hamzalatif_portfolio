import { motion } from "motion/react";
import { Link } from "react-router";
import { ArrowRight, Sparkles, Target, Zap } from "lucide-react";

export function Home() {
  return (
    <div className="pt-16 relative">
      {/* Subtle gradient background */}
      <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-transparent to-transparent pointer-events-none" />
      
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center px-6 lg:px-8">
        <div className="max-w-5xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center space-x-2 px-4 py-2 bg-card rounded-full mb-8 border border-border">
              <Sparkles className="w-4 h-4 text-primary" />
              <span className="text-sm text-muted-foreground">AI Product Manager</span>
            </div>
            <h1 className="mb-6 text-foreground">
              Building AI products that solve real problems
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-12 leading-relaxed">
              I lead product strategy for AI-powered platforms that transform how teams make decisions, 
              ship faster, and scale intelligently.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link
                to="/projects"
                className="w-full sm:w-auto inline-flex items-center justify-center px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors duration-200"
              >
                View Work
                <ArrowRight className="ml-2 w-4 h-4" />
              </Link>
              <Link
                to="/contact"
                className="w-full sm:w-auto inline-flex items-center justify-center px-6 py-3 bg-card text-foreground rounded-lg border border-border hover:border-primary/50 transition-colors duration-200"
              >
                Get in Touch
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Positioning Section */}
      <section className="py-32 px-6 lg:px-8 bg-card/30">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="grid md:grid-cols-3 gap-12"
          >
            <div className="space-y-4">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <Target className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-foreground">Strategic Vision</h3>
              <p className="text-muted-foreground leading-relaxed">
                Defining product roadmaps that align AI capabilities with market needs and business objectives.
              </p>
            </div>

            <div className="space-y-4">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <Zap className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-foreground">Execution Excellence</h3>
              <p className="text-muted-foreground leading-relaxed">
                Shipping complex AI features with cross-functional teams while maintaining quality and velocity.
              </p>
            </div>

            <div className="space-y-4">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-foreground">User-Centric AI</h3>
              <p className="text-muted-foreground leading-relaxed">
                Designing AI experiences that feel intuitive, trustworthy, and genuinely helpful to users.
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Featured Project */}
      <section className="py-32 px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="mb-8">
              <span className="text-sm text-primary uppercase tracking-wider">Featured Work</span>
            </div>
            <Link to="/projects/ai-compass" className="group">
              <div className="grid md:grid-cols-2 gap-12 items-center">
                <div className="space-y-6">
                  <h2 className="text-foreground group-hover:text-primary transition-colors duration-200">
                    AI Compass
                  </h2>
                  <p className="text-lg text-muted-foreground leading-relaxed">
                    An intelligent decision-making platform that helps product teams prioritize features using 
                    AI-powered insights, reducing decision time by 60%.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <span className="px-3 py-1 bg-card text-sm text-muted-foreground rounded-full border border-border">
                      Product Strategy
                    </span>
                    <span className="px-3 py-1 bg-card text-sm text-muted-foreground rounded-full border border-border">
                      ML Integration
                    </span>
                    <span className="px-3 py-1 bg-card text-sm text-muted-foreground rounded-full border border-border">
                      Enterprise SaaS
                    </span>
                  </div>
                  <div className="inline-flex items-center text-primary">
                    View Case Study
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform duration-200" />
                  </div>
                </div>
                <div className="aspect-video bg-card rounded-lg border border-border overflow-hidden group-hover:border-primary/50 transition-colors duration-200">
                  <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/20 to-primary/5">
                    <Target className="w-24 h-24 text-primary/40" />
                  </div>
                </div>
              </div>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Philosophy Section */}
      <section className="py-32 px-6 lg:px-8 bg-card/30">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center space-y-8"
          >
            <h2 className="text-foreground">Product Philosophy</h2>
            <div className="space-y-6 text-lg text-muted-foreground leading-relaxed">
              <p>
                The best AI products don't feel like AI products. They solve real problems elegantly, 
                with technology as the invisible enabler, not the headline.
              </p>
              <p>
                I believe in shipping iteratively, learning from users relentlessly, and building products 
                that earn trust through reliability and clarity—not hype.
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32 px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="space-y-8"
          >
            <h2 className="text-foreground">Let's build something together</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              I'm always interested in connecting with fellow product leaders, founders, and teams 
              working on meaningful AI products.
            </p>
            <Link
              to="/contact"
              className="inline-flex items-center px-8 py-4 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors duration-200"
            >
              Start a Conversation
              <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
}