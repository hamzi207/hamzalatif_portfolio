import { motion } from "motion/react";
import { Calendar, Clock, ArrowRight } from "lucide-react";

const blogPosts = [
  {
    id: 1,
    title: "Building Trust in AI Products: Lessons from the Frontlines",
    excerpt: "Why explainability matters more than accuracy when it comes to user adoption of AI features.",
    date: "Feb 10, 2026",
    readTime: "8 min read",
    category: "AI Product Management",
  },
  {
    id: 2,
    title: "The Product Manager's Guide to Working with Data Scientists",
    excerpt: "How to bridge the gap between product vision and technical implementation in ML projects.",
    date: "Jan 28, 2026",
    readTime: "6 min read",
    category: "Team Dynamics",
  },
  {
    id: 3,
    title: "From 0 to 1: Validating AI Product Ideas Before Writing Code",
    excerpt: "A framework for testing AI product hypotheses without building the full ML pipeline first.",
    date: "Jan 15, 2026",
    readTime: "10 min read",
    category: "Product Strategy",
  },
  {
    id: 4,
    title: "Why Most AI Features Fail (And How to Avoid It)",
    excerpt: "Common pitfalls in AI product development and strategies to ship features users actually want.",
    date: "Dec 20, 2025",
    readTime: "7 min read",
    category: "Product Development",
  },
  {
    id: 5,
    title: "Prioritization Frameworks for AI-First Products",
    excerpt: "How to evaluate and prioritize features when working with probabilistic systems.",
    date: "Dec 5, 2025",
    readTime: "9 min read",
    category: "Product Strategy",
  },
  {
    id: 6,
    title: "The Future of Product Management in an AI-Native World",
    excerpt: "How the PM role is evolving as AI becomes infrastructure rather than feature.",
    date: "Nov 22, 2025",
    readTime: "5 min read",
    category: "Industry Trends",
  },
];

export function Blog() {
  return (
    <div className="pt-32 pb-20 px-6 lg:px-8">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="space-y-16"
        >
          {/* Header */}
          <div className="space-y-6 max-w-3xl">
            <h1 className="text-foreground">Writing</h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              Thoughts on AI product management, building in public, and lessons learned 
              from shipping products at scale.
            </p>
          </div>

          {/* Blog Posts Grid */}
          <div className="space-y-6">
            {blogPosts.map((post, index) => (
              <motion.article
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                className="group p-8 bg-card border border-border rounded-lg hover:border-primary/50 transition-colors duration-200 cursor-pointer"
              >
                <div className="space-y-4">
                  <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                    <span className="px-3 py-1 bg-primary/10 text-primary rounded-full">
                      {post.category}
                    </span>
                    <div className="flex items-center space-x-1">
                      <Calendar className="w-4 h-4" />
                      <span>{post.date}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Clock className="w-4 h-4" />
                      <span>{post.readTime}</span>
                    </div>
                  </div>
                  
                  <h3 className="text-foreground group-hover:text-primary transition-colors duration-200">
                    {post.title}
                  </h3>
                  
                  <p className="text-muted-foreground leading-relaxed">
                    {post.excerpt}
                  </p>
                  
                  <div className="inline-flex items-center text-primary opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                    Read More
                    <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform duration-200" />
                  </div>
                </div>
              </motion.article>
            ))}
          </div>

          {/* Newsletter CTA */}
          <div className="pt-8 text-center">
            <div className="p-8 bg-card border border-border rounded-lg space-y-4 max-w-2xl mx-auto">
              <h3 className="text-foreground">Stay Updated</h3>
              <p className="text-muted-foreground">
                Get notified when I publish new articles about AI product management and 
                building great products.
              </p>
              <div className="flex gap-3 max-w-md mx-auto pt-2">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="flex-1 px-4 py-2 bg-background border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                />
                <button className="px-6 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors duration-200">
                  Subscribe
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
